#!/usr/bin/env python
# coding: utf-8

# In[3]:


from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self, username, password):
        # Connection Variables
        USER = username
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32329
        DB = 'AAC'
        COL = 'animals'
        
        # Initialize Connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]
    
    #method to implement C in CRUD - Create
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data) #data should be dictionary
        else:
            raise Exception("Nothing to save, because data parameter is empty") #throw exception if imput is empty
            
    #method to implement the R in CRUD - Read
    def read(self, criteria=None): #use given criteria to search for entry
        try: 
            if criteria is not None:
                cursor = self.database.animals.find(criteria, {"_id": False}) #use cursor to find criteria
            else:
                cursor = self.database.animals.find({}, {"_id": False})
                
            documents = [document for document in cursor] #convert cursor object into a list
            return documents #return list
        except Exception as e:
            raise Exception(f"An error has occured while reading files: {e}") #throw exception if there is a problem finding criteria

    #method to implement U in CRUD - Update
    def update(self, criteria, update_data):
        if criteria and update_data:
            try:
                result = self.collection.update_many(criteria, update_data)
                return result.modified_count  # Return the number of modified documents
            except Exception as e:
                raise Exception(f"An error occurred while updating documents: {e}")
        else:
            raise Exception("Invalid criteria or update data provided.")
            
    #method to implement D in CRUD - Delete
    def delete(self, criteria):
        if criteria:
            try:
                result = self.collection.delete_many(criteria)
                return result.deleted_count  # Return the number of deleted documents
            except Exception as e:
                raise Exception(f"An error occurred while deleting documents: {e}")
        else:
            raise Exception("Invalid criteria provided.")


# In[ ]:




